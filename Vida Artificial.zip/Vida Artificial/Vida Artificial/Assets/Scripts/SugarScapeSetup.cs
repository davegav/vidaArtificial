﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SugarScapeSetup : MonoBehaviour {

	Color empty = Color.white;
	Color low = Color.gray;
	Color meddium = Color.yellow;
	Color high = Color.green;
	public int season = 1;

	void changeSeason () {
		season = season * -1;
	}

	// Use this for initialization
	void Start () {

		int i = 0;
		foreach (Transform child in transform) {
			this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().maxAmount = 30;
			i++;
		}

		//Lsystems initial sandpile
		if (season == 1) {
			this.GetComponent<Transform> ().GetChild (463).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (207).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (704).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (607).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (497).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (313).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
		} else {
			this.GetComponent<Transform> ().GetChild (1423).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (886).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (1364).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (987).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (1074).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (933).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (1291).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (1259).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
			this.GetComponent<Transform> ().GetChild (1210).GetComponent<FoodData> ().amount += (int)Random.Range (400f, 500f);
		}

	}


	private float time = 0.0f;
	public float interpolationPeriod = 0.2f;
	private float timeSeason = 0.0f;
	public float interpolationPeriodSeason = 4f;
	// Update is called once per frame
	void Update () {


		time += Time.deltaTime;
		timeSeason += Time.deltaTime;


		if (timeSeason >= interpolationPeriodSeason) {
			timeSeason = 0.0f;
			changeSeason ();
		}

		if (time >= interpolationPeriod) {
			time = 0.0f;

			//Lsystems initial sandpile
			if (season == 1) {
				this.GetComponent<Transform> ().GetChild (463).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (207).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (704).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (607).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (497).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (313).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
			} else {
				this.GetComponent<Transform> ().GetChild (1423).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (886).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (1364).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (987).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (1074).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (933).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (1291).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (1259).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
				this.GetComponent<Transform> ().GetChild (1210).GetComponent<FoodData> ().amount += (int)Random.Range (5f, 15f);
			}
				

			bool derrumbe = false;
			int i = 0;
			foreach (Transform child in transform) {
				if (this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount > this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().maxAmount) {
					derrumbe = true;
				}
				i++;
			}


			while (derrumbe) {
				i = 0;
				foreach (Transform child in transform) {
					if (this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount > this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().maxAmount) {
						if (i > 39) {
							this.gameObject.transform.GetChild (i - 40).GetComponent<FoodData> ().amount += 1;
						}
						if ((i % 40) != 0) {
							this.gameObject.transform.GetChild (i - 1).GetComponent<FoodData> ().amount += 1;
						}
						if (((i + 1) % 40) != 0) {
							this.gameObject.transform.GetChild (i + 1).GetComponent<FoodData> ().amount += 1;
						}
						if (i < 1560) {
							this.gameObject.transform.GetChild (i + 40).GetComponent<FoodData> ().amount += 1;
						}

						this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount -= 4;
					}
					i++;
				}

				derrumbe = false;
				i = 0;
				foreach (Transform child in transform) {
					if (this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount > this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().maxAmount) {
						derrumbe = true;
					}
					i++;
				}
			}

			i = 0;
			foreach (Transform child in transform) {

				if (this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount <= 0) {
					this.gameObject.transform.GetChild (i).GetComponent<MeshRenderer> ().material.color = empty;
				} else {
					if (this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount <= 10) {
						this.gameObject.transform.GetChild (i).GetComponent<MeshRenderer> ().material.color = low;
					} else {
						if (this.gameObject.transform.GetChild (i).GetComponent<FoodData> ().amount <= 20) {
							this.gameObject.transform.GetChild (i).GetComponent<MeshRenderer> ().material.color = meddium;
						} else {
							this.gameObject.transform.GetChild (i).GetComponent<MeshRenderer> ().material.color = high;
						}
					}
				}
				i++;
			}
		}
	}
}
