﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PredatorSetup : MonoBehaviour {

	public GameObject Predator;

	// Use this for initialization
	void Start () {
		GameObject newPredator = (GameObject)Instantiate (Predator);
		newPredator.transform.position = new Vector3(0, 0, 0);
		newPredator.transform.parent = transform;
		for (int x = 0; x < 10; x++) {
			newPredator = (GameObject)Instantiate (Predator);
			newPredator.transform.position = new Vector3(4*x, 0, 0);
			newPredator.transform.parent = transform;
		}
		
	}
}
