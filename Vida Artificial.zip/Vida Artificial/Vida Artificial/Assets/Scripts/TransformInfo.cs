﻿using System.Collections;
using UnityEngine;

public class TransformInfo {
    public Vector3 position;
    public Quaternion rotation;
}
