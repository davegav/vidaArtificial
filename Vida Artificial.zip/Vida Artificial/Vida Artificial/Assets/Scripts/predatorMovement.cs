﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class predatorMovement : MonoBehaviour{

	public GameObject Predator;

	public float minimumSugarEndowment = 10f;
	public float maximunSugarEndowment = 200f;
	public float sugar;
	public float vision;
	public float metabolism;
	public float maxAge;
	public float age;
	public bool male;
	public float velocity;
	public float celo = -5.0f;
	public int fitness = 0;
	public float[] adn = new float[10];


	private Transform wife;

	void Start () {

		//Genetic code
		//3 numbers from 0 to 1 (Color)
		//number of visión between (80,1000)
		//Metabolism between (1,10)
		//maxAge between (60, 100)
		//Velocity between (2, 20)
		//3 numbers from the scale
		//setup genetic code
		adn[0] = Random.Range(0.8f, 1f);
		adn[1] = Random.Range(0.7f, 1f);
		adn[2] = Random.Range(0f, 0.3f);
		adn[3] = Random.Range(400f,1000f);
		adn[4] = Random.Range(1f,8f);
		adn[5] = Random.Range(50f,80f);
		adn[6] = Random.Range(7f,20f);
		adn[7] = Random.Range(8f,12f);
		adn[8] = Random.Range(8f,12f);
		adn[9] = Random.Range(8f,12f);

		//implemet genetic code

		this.gameObject.GetComponent<RDGenerator>().color = new Color(adn[0], adn[1], adn[2], 1f);
		vision = adn[3];
		metabolism = adn[4];
		maxAge = adn[5];
		velocity = adn[6];
		transform.localScale = new Vector3(adn[7], adn[8], adn[9]);


		age = 0;
		sugar = maximunSugarEndowment * 3;


		if (Random.Range (0f, 100f) < 50) {
			male = true;
		} else {
			male = false;
		}
	}



	void Update () {
		
		age += 0.1f;
		celo += 0.1f;
		if (age > maxAge){
			Destroy (this.gameObject);
		}

		//Food

		ArrayList possibleWinners = new ArrayList ();

		foreach (Transform child in transform.parent.parent.GetChild(0).transform) {
			float distance = (transform.position - child.position).magnitude;
			if (distance < vision) {
				possibleWinners.Add (child);
			}
		}
		Transform destiny = null;
		float minDistance = 100000000;

		if (possibleWinners.Count > 0) {
			foreach (Transform patchIndex in possibleWinners) {
				float distance = (transform.position - patchIndex.position).magnitude;
				if (distance < minDistance) {
					destiny = patchIndex;
					minDistance = distance;
				}
			
			}
		}


		//Reproduction
		ArrayList neighbors = new ArrayList ();
		foreach (Transform child in transform.parent) {
			if (child != transform) {
				float distanceSqr = (transform.position - child.position).magnitude;
				if (distanceSqr < (vision * 1.5) ) {
					neighbors.Add (child);
				}
			}
		}
		if (neighbors.Count == 0) {
			if (sugar < 150) {   //if he is hungry, looks for food
				if (possibleWinners.Count > 0) {
					transform.LookAt (destiny);
				} else {
					transform.Rotate (0, Random.Range (0, 180), 0);
				}

				transform.Translate (0, 0, velocity);
				float xx = transform.position.x;
				float zz = transform.position.z;
				float yy = transform.position.y;

				if (xx > 2000) { 
					xx = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (xx < -2000) { 
						xx = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				if (zz > 2000) { 
					zz = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (zz < -2000) { 
						zz = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				transform.position = new Vector3 (xx, yy, zz);


				//eat
				float quantity = 0f;
				if (possibleWinners.Count > 0) {
					float distanceSqr = (transform.position - destiny.position).magnitude;
					if (distanceSqr < 50) {
						//close enougth to eat the pray
						quantity = destiny.gameObject.GetComponent<PrayMovement> ().sugar * 2.2f;
						sugar = sugar + quantity - metabolism;
						Destroy (destiny.gameObject);
						//Aumentar el fitness por comer
						fitness += 1;
					}
				} else {
					sugar -= 0.5f;
				}
			} else {
				transform.Rotate (0, Random.Range (0, 60) - 30, 0); //Random movement
				float xx = transform.position.x;
				float zz = transform.position.z;

				if (xx > 2000) { 
					xx = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (xx < -2000) { 
						xx = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				if (zz > 2000) { 
					zz = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (zz < -2000) { 
						zz = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				transform.Translate (0, 0, velocity);
				sugar -= 0.5f;
			}
		} else {
			bool eatThisTime = false;
			if (sugar > 80) {
				if (male && (celo > 8.0)) {  //female are passive
					ArrayList possiblePartners = new ArrayList ();
					foreach (Transform partner in neighbors) {
						if ((!partner.gameObject.GetComponent<predatorMovement> ().male) && (partner.gameObject.GetComponent<predatorMovement> ().celo > 8.0)) {
							possiblePartners.Add (partner);
						}
					}
					//Choose partner with best fitness function
					if (possiblePartners.Count > 0) {
						float maxFitness = 0f;
						foreach (Transform partner in possiblePartners) {
							if (partner.gameObject.GetComponent<predatorMovement> ().fitness >= maxFitness) {
								wife = partner;
								maxFitness = partner.gameObject.GetComponent<predatorMovement> ().fitness;
							}
						}
							
						float probMate = Random.Range (0, 100);
						if (probMate < 60) {    //Not always reproduce
							transform.LookAt (wife);
							float dist = Vector3.Distance (wife.position, transform.position);
							if (velocity > dist) {
								transform.Translate (0, 0, (dist * 0.8f));
							} else {
								transform.Translate (0, 0, velocity);
							}
							//Aumentar el fitness por reproducirse

							fitness += 1;
							wife.gameObject.GetComponent<predatorMovement> ().fitness += 1;

							//Crear hijo y reiniciar el celo de ambos padres, revisar que esta lo suficientemente cerca para aparearse

							GameObject son = (GameObject)Instantiate (Predator, transform.position, Quaternion.identity, transform.parent);
							son.transform.Translate (0, 0, 10);
							celo = 0f;
							wife.GetComponent<predatorMovement> ().celo = 0f;

							//transferir codigo genetico de los padres
							float[] sonAdn = new float[10];
							ArrayList numeros = new ArrayList ();
							numeros.Add (0);
							numeros.Add (1);
							numeros.Add (2);
							numeros.Add (3);
							numeros.Add (4);
							numeros.Add (5);
							numeros.Add (6);
							numeros.Add (7);
							numeros.Add (8);
							numeros.Add (9);

							for (int i = 0; i < 5; i++) {
								numeros.Remove ((int)Random.Range (0f, numeros.Count));
							}
							for (int i = 0; i < 10; i++) {
								if (numeros.Contains (i)) {
									sonAdn [i] = wife.GetComponent<predatorMovement> ().adn [i];
								} else {
									sonAdn [i] = this.gameObject.GetComponent<predatorMovement> ().adn [i];
								}
							}
							//Crossover process
							for (int i = 0; i < 10; i++) {
								if (Random.Range (0f, 10f) < 100) {
									if (i < 3) {
										sonAdn [i] = sonAdn [i] + (Random.Range (0f, 0.2f) - 0.1f);
										if (sonAdn [i] < 0f) {
											sonAdn [i] = 0f;
										} else {
											if (sonAdn [i] > 1f) {
												sonAdn [i] = 1f;
											}
										}
									} else {
										if (i == 3) {
											sonAdn [i] = sonAdn [i] + (Random.Range (0f, 100f) - 50f);
											if (sonAdn [i] < 100f) {
												sonAdn [i] = 100f;
											} else {
												if (sonAdn [i] > 1000f) {
													sonAdn [i] = 1000f;
												}
											}
										} else {
											if (i == 4) {
												sonAdn [i] = sonAdn [i] + (Random.Range (0f, 2f) - 1f);
												if (sonAdn [i] < 1f) {
													sonAdn [i] = 1f;
												} else {
													if (sonAdn [i] > 10f) {
														sonAdn [i] = 10f;
													}
												}
											} else {
												if (i == 5) {
													sonAdn [i] = sonAdn [i] + (Random.Range (0f, 10f) - 5f);
													if (sonAdn [i] < 40f) {
														sonAdn [i] = 40f;
													} else {
														if (sonAdn [i] > 120f) {
															sonAdn [i] = 120f;
														}
													}
												} else {
													if (i == 6) {
														sonAdn [i] = sonAdn [i] + (Random.Range (0f, 4f) - 2f);
														if (sonAdn [i] < 2f) {
															sonAdn [i] = 2f;
														} else {
															if (sonAdn [i] > 22f) {
																sonAdn [i] = 22f;
															}
														}
													} else {
														sonAdn [i] = sonAdn [i] + (Random.Range (0f, 0.4f) - 0.2f);
														if (sonAdn [i] < 7f) {
															sonAdn [i] = 7f;
														} else {
															if (sonAdn [i] > 14f) {
																sonAdn [i] = 14f;
															}
														}
													}
												}
											}
										}
									}	
								}
							}
							//The mutation is particular per gene
							sugar = sugar / 2;
							wife.GetComponent<predatorMovement> ().sugar = wife.GetComponent<predatorMovement> ().sugar / 2;
							son.GetComponent<predatorMovement> ().sugar = sugar + wife.GetComponent<predatorMovement> ().sugar;

							//Herency of sugar 

						}
					} 
				}
			} else {
				eatThisTime = true;
			}
				



			if (eatThisTime) {

				if (possibleWinners.Count > 0) {
					transform.LookAt (destiny);
				} else {
					transform.Rotate (0, Random.Range (0, 50), 0);
				}

				transform.Translate (0, 0, velocity);
				float xx = transform.position.x;
				float zz = transform.position.z;
				float yy = transform.position.y;

				if (xx > 2000) { 
					xx = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (xx < -2000) { 
						xx = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				if (zz > 2000) { 
					zz = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (zz < -2000) { 
						zz = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				transform.position = new Vector3 (xx, yy, zz);


				//eat
				float quantity = 0f;
				if (possibleWinners.Count > 0) {
					float distanceSqr = (transform.position - destiny.position).magnitude;
					if (distanceSqr < 50) {
						//close enougth to eat the pray
						quantity = destiny.gameObject.GetComponent<PrayMovement> ().sugar;
						sugar = sugar + quantity - metabolism;
						Destroy (destiny.gameObject);
					}
				} else {
					sugar -= 0.5f;
				}

			} else {
				
				transform.Rotate (0, Random.Range (0, 40) - 20, 0); //Random movement
				transform.Translate (0, 0, velocity);
				float xx = transform.position.x;
				float zz = transform.position.z;
				float yy = transform.position.y;

				if (xx > 2000) { 
					xx = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (xx < -2000) { 
						xx = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				if (zz > 2000) { 
					zz = 2000;
					transform.Rotate (0, 180, 0);
				} else { 
					if (zz < -2000) { 
						zz = -2000;
						transform.Rotate (0, 180, 0);
					}
				}
				transform.position = new Vector3 (xx, yy, zz);
				sugar -= 0.5f;
			}
		}


		if (sugar <= 0) {
			Destroy (this.gameObject);
		}
	}
}