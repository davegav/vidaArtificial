﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RDGeneratorPray : MonoBehaviour {
	public int width = 128;
	public int heigth = 128;

	public float dA = 1f;
	public float dB = 0.5f;
	public float f = 0.039f;
	public float k = 0.058f;
	public Color color = new Color(0.5f, 0.6f, 0.6f ,1f);


	private RDCellPray[,] grid;
	private Texture2D texture;
	private RDCellPray[,] previusGrid;
	private bool converge = false;


	// Use this for initialization
	void Start () {
		InitializeTexture ();
		InitializeGrid ();
		//4000
		for (int i = 0; i <10; i++) {
			GenerateNextGrid ();
		}
		RefreshTexture (); 
	}

	// Update is called once per frame
	void Update () {
//		if (!converge) {
//			checkConvergence ();
//			GenerateNextGrid ();
//			RefreshTexture ();
//		}
		//Comentado para mejorar el rendimiento quitando el Turing morph
	}

	void InitializeTexture () {
		texture = new Texture2D (width, heigth);
		Renderer renderer = GetComponent<Renderer> ();
		renderer.material.mainTexture = texture;
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < width; y++) {
				texture.SetPixel (x, y, Color.cyan);
			}
		}
		texture.Apply ();
	}

	void InitializeGrid () {

		grid = new RDCellPray[width, heigth];
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < width; y++) {
				grid [x, y] = new RDCellPray ();
			}
		}

		int poss1 = (int) Random.Range (0f, 100f);
		int poss2 = (int) Random.Range (0f, 100f);
		int poss3 = (int) Random.Range (0f, 100f);
		int poss4 = (int) Random.Range (0f, 100f);

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				grid [poss1 + i, poss2 + j].B = 1f;
				grid [poss2 + i, poss1 + j].B = 1f;
				grid [poss3 + i, poss4 + j].B = 1f;
				grid [poss4 + i, poss3 + j].B = 1f;
			}
		}
	}


	int mod(int a, int n) {
		return ((a%n)+n) % n;
	}

	void checkConvergence(){

		if (matrixEquals (previusGrid, grid)) {
			converge = true;
			Debug.Log ("Convergence achieve");
		}
	}

	bool matrixEquals(RDCellPray[,] matrix1, RDCellPray[,] matrix2){

		bool result = true;

		for (int i = 0; i < 128; i++) {
			for (int j = 0; j < 128; j++) {
				if (matrix1 [i, j] != matrix2 [i, j])
					return false;
			}
		}	

		return result;
	}




	void GenerateNextGrid () {
		RDCellPray[,] nextGrid = new RDCellPray[width, heigth];

		for (int x = 0; x < width; x++) {
			for (int y = 0; y < width; y++) {
				nextGrid [x, y] = new RDCellPray ();
			}
		}
		for (int x = 1; x < width-1; x++) {
			for (int y = 1; y < width-1; y++) {
				float a = grid [x, y].A;
				float b = grid [x, y].B;

				nextGrid [x, y].A = a + (dA * LaplaceA (x, y) - (a * b * b) + (f * (1 - a)));
				nextGrid [x, y].B = b + (dB * LaplaceB (x, y) + (a * b * b) - ((k + f) * b));			
			}
		}
		previusGrid = grid;
		grid = nextGrid;

	}

	float LaplaceA(int x, int y){
		float returnSum = grid [x, y].A * -1f;

		returnSum += grid [x + 1, y].A * 0.2f;
		returnSum += grid [x - 1, y].A * 0.2f;
		returnSum += grid [x, y + 1].A * 0.2f;
		returnSum += grid [x, y - 1].A * 0.2f;

		returnSum += grid [x - 1, y - 1].A * 0.05f;
		returnSum += grid [x - 1, y + 1].A * 0.05f;
		returnSum += grid [x + 1, y - 1].A * 0.05f;
		returnSum += grid [x + 1, y + 1].A * 0.05f;

		return returnSum;
	}

	float LaplaceB(int x, int y){
		float returnSum = grid [x, y].B * -1f;

		returnSum += grid [x, y + 1].B * 0.2f;
		returnSum += grid [x, y - 1].B * 0.2f;
		returnSum += grid [x + 1, y].B * 0.2f;
		returnSum += grid [x - 1, y].B * 0.2f;

		returnSum += grid [x - 1, y - 1].B * 0.05f;
		returnSum += grid [x - 1, y + 1].B * 0.05f;
		returnSum += grid [x + 1, y - 1].B * 0.05f;
		returnSum += grid [x + 1, y + 1].B * 0.05f;

		return returnSum;
	}


	void RefreshTexture () {
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < width; y++) {
				texture.SetPixel (x, y, Color.Lerp (color, Color.white, grid[x, y].B * 3f));
			}
		}
		texture.Apply();
	}
}