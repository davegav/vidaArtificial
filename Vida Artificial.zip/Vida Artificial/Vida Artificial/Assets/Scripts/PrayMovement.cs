﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrayMovement : MonoBehaviour {

	public GameObject Pray;

	public float minimumSugarEndowment = 5f;
	public float maximunSugarEndowment = 25f;
	public float sugar;
	public float vision;
	public float metabolism;
	public float maxAge;
	public float age;
	public bool male;
	public float velocity;
	public float celo = 0f;
	public int fitness = 0;
	public float[] adn = new float[10];
	//Genetic code
	//3 numbers from 0 to 1 (Color)
	//number of visión between (80,1000)
	//Metabolism between (1,10)
	//maxAge between (60, 100)
	//Velocity between (2, 20)
	//3 numbers from the scale


	private Transform wife;

	void Start () {
		//setup genetic code
		adn[0] = Random.Range(0.4f, 0.7f);
		adn[1] = Random.Range(0.4f, 0.7f);
		adn[2] = Random.Range(0.4f, 0.7f);
		adn[3] = Random.Range(200f,700f);
		adn[4] = Random.Range(0.4f,5f);
		adn[5] = Random.Range(30f,60f);
		adn[6] = Random.Range(5f,18f);
		adn[7] = Random.Range(0.5f,1f);
		adn[8] = Random.Range(0.5f,1f);
		adn[9] = Random.Range(0.5f,1f);

		//implemet genetic code

		this.gameObject.GetComponent<RDGeneratorPray>().color = new Color(adn[0], adn[1], adn[2], 1f);
		vision = adn[3];
		metabolism = adn[4];
		maxAge = adn[5];
		velocity = adn[6];
		transform.localScale = new Vector3(adn[7], adn[8], adn[9]);


		age = 0;
		sugar = maximunSugarEndowment * 3;


		if (Random.Range (0f, 100f) < 50) {
			male = true;
		} else {
			male = false;
		}
	}
		
	public float distanceCohesion = 20f;

	void Update () {
		
		transform.rotation = Quaternion.Euler(0, transform.rotation.y, 0);
		age += 0.1f;
		celo += 0.1f;

		if (age > maxAge){
			Destroy (this.gameObject);
		}

		if (transform.position.y < -1f) {
			transform.position = new Vector3 (transform.position.x, 0.2f, transform.position.z);
		}
		//Food

		ArrayList possibleWinners = new ArrayList ();

		foreach (Transform child in transform.parent.parent.GetChild(2).transform) {
			float distance = (transform.position - child.position).magnitude;
			if (distance < vision) {
				possibleWinners.Add (child);
			}
		}
		Transform destiny = null;
		Transform closestPatch = null;
		float minHeuristic = 1000000000f;
		float minDistance = 1000000000f;

		foreach (Transform patchIndex in possibleWinners) {
			float distance = (transform.position - patchIndex.position).magnitude;
			int heuristic = patchIndex.gameObject.GetComponent<FoodData>().amount;
			if ((distance * (40 - heuristic)) < minHeuristic) {
				destiny = patchIndex;
				minHeuristic = distance * (40 - heuristic);
			}
			if (distance < minDistance) {
				closestPatch = patchIndex;
				minDistance = distance;
			}

		}
			

		//near enemy

		Transform nearPredator = null;
		float minDistEnem = 1000000000f;
		foreach (Transform child in transform.parent.parent.GetChild(1).transform) {
			float distanceSqr = (transform.position - child.position).magnitude;
			if (distanceSqr < vision) {
				if (distanceSqr < minDistEnem) {
					nearPredator = child;
					minDistEnem = distanceSqr;
				}
			}
		}

		//Boids
		ArrayList neighbors = new ArrayList ();
		Transform nearBoid;
		foreach (Transform child in transform.parent.parent.GetChild(0).transform) {
			if (child != transform) {
				float distanceSqr = (transform.position - child.position).magnitude;
				if (distanceSqr < (vision/2)) {
					neighbors.Add (child);
				}
			}
		}
		if (neighbors.Count == 0) {
			
			float xx = transform.position.x;
			float zz = transform.position.z;
			float yy = transform.position.y;
			if (xx > 1900) { 
				xx -= 3800;
				transform.Rotate (0, 30, 0);
				transform.position = new Vector3 (xx, yy, zz);
			} else { 
				if (xx < -1900) { 
					xx += 3800;
					transform.Rotate (0, 30, 0);
					transform.position = new Vector3 (xx, yy, zz);
				} else {
					if (!(closestPatch == destiny)) {
						transform.LookAt (destiny);
						transform.Translate (0, 0, velocity);
					} else {
						if (minDistEnem < vision) {
							transform.LookAt (nearPredator);
							transform.Rotate (0, 180, 0);
							transform.Translate (0, 0, velocity);
						} else {
							transform.Rotate (0, Random.Range(0, 20) - 10, 0);
							transform.Translate (0, 0, velocity);
						}
					}

				}
			}
			if (zz > 1900) { 
				zz -= 3800;
				transform.Rotate (0, 30, 0);
				transform.position = new Vector3 (xx, yy, zz);
			} else { 
				if (zz < -1900) { 
					transform.Rotate (0, 30, 0);
					zz += 3800;
					transform.position = new Vector3 (xx, yy, zz);
				} else {
					if (destiny != null) {
						if (destiny.gameObject.GetComponent<FoodData> ().amount == 0) {
							if (minDistEnem < vision) {
								transform.LookAt (nearPredator);
								transform.Rotate (0, 180, 0);
								transform.Translate (0, 0, velocity);
							} else {
								transform.Rotate (0, Random.Range (0, 20) - 10, 0);
								transform.Translate (0, 0, velocity);
							}
						} else {
							transform.LookAt (destiny);
							transform.Translate (0, 0, velocity);
						}
					}

				}
			}
				
		} else {

			//Reproduction
			if (male && (celo > 2.0)) {  //female are passive
				ArrayList possiblePartners = new ArrayList ();
				foreach (Transform partner in neighbors) {
					if ((!partner.gameObject.GetComponent<PrayMovement> ().male) && (partner.gameObject.GetComponent<PrayMovement> ().celo > 2.0)) {
						possiblePartners.Add (partner);
					}
				}
				//Choose partner with best fitness function
				if (possiblePartners.Count > 0) {
					int maxFitness = 0;
					foreach (Transform partner in possiblePartners) {
						if (partner.gameObject.GetComponent<PrayMovement> ().fitness >= maxFitness) {
							wife = partner;
							maxFitness = partner.gameObject.GetComponent<PrayMovement> ().fitness;
						}
					}
					float probMate = Random.Range (0, 100);
					if (probMate < 99) {    
						transform.LookAt (wife);
						float dist = Vector3.Distance (wife.position, transform.position);
						if (velocity > dist) {
							transform.Translate (0, 0, (dist * 0.8f));
						} else {
							transform.Translate (0, 0, velocity);
						}

						//Aumentar el fitness para los padres

						fitness += 1;
						wife.gameObject.GetComponent<PrayMovement> ().fitness += 1;

						//Crear hijo y reiniciar el celo de ambos padres

						GameObject son = (GameObject)Instantiate (Pray, transform.position, Quaternion.identity, transform.parent);
						son.transform.Translate (0, 0, 10);
						celo = 0f;
						wife.GetComponent<PrayMovement> ().celo = 0f;
						//transferir codigo genetico de los padres
						float[] sonAdn = new float[10];
						ArrayList numeros = new ArrayList ();
						numeros.Add (0);
						numeros.Add (1);
						numeros.Add (2);
						numeros.Add (3);
						numeros.Add (4);
						numeros.Add (5);
						numeros.Add (6);
						numeros.Add (7);
						numeros.Add (8);
						numeros.Add (9);

						for (int i = 0; i < 5; i++) {
							numeros.Remove ((int) Random.Range(0f, numeros.Count));
						}
						for (int i = 0; i < 10; i++) {
							if (numeros.Contains (i)) {
								sonAdn [i] = wife.GetComponent<PrayMovement> ().adn [i];
							} else {
								sonAdn [i] = this.gameObject.GetComponent<PrayMovement> ().adn [i];
							}
						}
						//Crossover process
						for (int i = 0; i < 10; i++) {
							if (Random.Range(0f, 10f) < 100) {
								if (i < 3) {
									sonAdn [i] = sonAdn [i] + (Random.Range (0f, 0.2f) - 0.1f);
									if (sonAdn [i] < 0f) {
										sonAdn [i] = 0f;
									} else {
										if (sonAdn [i] > 1f) {
											sonAdn [i] = 1f;
										}
									}
								} else {
									if (i == 3) {
										sonAdn [i] = sonAdn [i] + (Random.Range (0f, 100f) - 50f);
										if (sonAdn [i] < 100f) {
											sonAdn [i] = 100f;
										} else {
											if (sonAdn [i] > 1000f) {
												sonAdn [i] = 1000f;
											}
										}
									} else {
										if (i == 4) {
											sonAdn [i] = sonAdn [i] + (Random.Range (0f, 2f) - 1f);
											if (sonAdn [i] < 1f) {
												sonAdn [i] = 1f;
											} else {
												if (sonAdn [i] > 10f) {
													sonAdn [i] = 10f;
												}
											}
										} else {
											if (i == 5) {
												sonAdn [i] = sonAdn [i] + (Random.Range (0f, 10f) - 5f);
												if (sonAdn [i] < 40f) {
													sonAdn [i] = 40f;
												} else {
													if (sonAdn [i] > 120f) {
														sonAdn [i] = 120f;
													}
												}
											} else {
												if (i == 6) {
													sonAdn [i] = sonAdn [i] + (Random.Range (0f, 4f) - 2f);
													if (sonAdn [i] < 2f) {
														sonAdn [i] = 2f;
													} else {
														if (sonAdn [i] > 22f) {
															sonAdn [i] = 22f;
														}
													}
												} else {
													sonAdn [i] = sonAdn [i] + (Random.Range (0f, 0.2f) - 0.1f);
													if (sonAdn [i] < 0f) {
														sonAdn [i] = 0f;
													} else {
														if (sonAdn [i] > 1f) {
															sonAdn [i] = 1f;
														}
													}
												}
											}
										}
									}
								}	
							}
						}
						//The mutation is particular per gene
						sugar = sugar / 2;
						wife.GetComponent<PrayMovement> ().sugar = wife.GetComponent<PrayMovement> ().sugar / 2;
						son.GetComponent<PrayMovement>().sugar = sugar + wife.GetComponent<PrayMovement> ().sugar;

						//Herency of sugar 
					}
				}
			}
			
			nearBoid = null;
			float minDist = 10000000000f;
			foreach (Transform child in neighbors) {
				float dist = Vector3.Distance (child.position, transform.position);
				if (dist < minDist) {
					nearBoid = child;
					minDist = dist;
				}
			}

			float xx = transform.position.x;
			float zz = transform.position.z;
			float yy = transform.position.y;
			if (xx > 1900) { 
				xx -= 3800;
				transform.Rotate (0, 150, 0);
				transform.position = new Vector3 (xx, yy, zz);
			} else { 
				if (xx < -1900) { 
					xx += 3800;
					transform.Rotate (0, 150, 0);
					transform.position = new Vector3 (xx, yy, zz);
				} else {
					if (minDist < distanceCohesion) {

						transform.LookAt (nearBoid);
						transform.Rotate (0, 180, 0);
						transform.Translate (0, 0, velocity);
						//separate

					} else {
						float degreesAcumX = 0f;
						float degreesAcumY = 0f;
						int conteo = 0;
						if (destiny.gameObject.GetComponent<FoodData>().amount > 0) {
							transform.LookAt (destiny);
							degreesAcumX = Mathf.Cos (transform.eulerAngles.y) * 40;
							degreesAcumY = Mathf.Sin (transform.eulerAngles.y) * 40;
							conteo = 40;
						}
						if (minDistEnem < vision) {    //Run from predator
							transform.LookAt (nearPredator);
							transform.Rotate (0, 180, 0);
							degreesAcumX += Mathf.Cos (transform.eulerAngles.y) * 8;
							degreesAcumY += Mathf.Sin (transform.eulerAngles.y) * 8;
							conteo += 8;
						}

						//pointing towars food

						foreach (Transform child in neighbors) {
							degreesAcumX = Mathf.Cos (child.eulerAngles.y);
							degreesAcumY = Mathf.Sin (child.eulerAngles.y);
							conteo++;
						}
						degreesAcumX = degreesAcumX / conteo;
						degreesAcumY = degreesAcumY / conteo;
						float finalAngle = Mathf.Atan (degreesAcumY / degreesAcumX);
						transform.eulerAngles = new Vector3 (0, finalAngle, 0);

						//Align

						transform.Translate (0, 0, velocity);
						//Cohere

					}
				}
			}
			if (zz > 1900) { 
				zz -= 3800;
				transform.Rotate (0, 150, 0);
				transform.position = new Vector3 (xx, yy, zz);
			} else { 
				if (zz < -1900) { 
					zz += 3800;
					transform.Rotate (0, 150, 0);
					transform.position = new Vector3 (xx, yy, zz);
				} else {
					if (minDist < distanceCohesion) {

						transform.LookAt (nearBoid);
						transform.Rotate (0, 180, 0);
						transform.Translate (0, 0, velocity);
						//separate

					} else {
						float degreesAcumX = 0f;
						float degreesAcumY = 0f;
						int conteo = 0;

						if (destiny.gameObject.GetComponent<FoodData>().amount > 0) {
							transform.LookAt (destiny);
							degreesAcumX = Mathf.Cos (transform.eulerAngles.y) * 30;
							degreesAcumY = Mathf.Sin (transform.eulerAngles.y) * 30;
							conteo = 30;
						}
						if (minDistEnem < vision) {    //Run from predator
							transform.LookAt (nearPredator);
							transform.Rotate (0, 180, 0);
							degreesAcumX += Mathf.Cos (transform.eulerAngles.y) * 8;
							degreesAcumY += Mathf.Sin (transform.eulerAngles.y) * 8;
							conteo += 8;
						}

						//pointing towars food

						foreach (Transform child in neighbors) {
							degreesAcumX = Mathf.Cos (child.eulerAngles.y);
							degreesAcumY = Mathf.Sin (child.eulerAngles.y);
							conteo++;
						}
						degreesAcumX = degreesAcumX / conteo;
						degreesAcumY = degreesAcumY / conteo;
						float finalAngle = Mathf.Atan (degreesAcumY / degreesAcumX);
						transform.eulerAngles = new Vector3 (0, finalAngle, 0);

						//Align

						transform.Translate (0, 0, velocity);
						//Cohere

					}
				}
			}





		}

		Transform patch = null;
		minHeuristic = 10000000;
		foreach (Transform patchIndex in possibleWinners) {
			float distance = (transform.position - patchIndex.position).magnitude;
			if (distance < minHeuristic) {
				patch = patchIndex;
				minHeuristic = distance ;
			}
		}
		int quantity = 0;
		if (patch != null) {
			if (patch.gameObject.GetComponent<FoodData> ().amount > 10) {
				quantity = 10;
			} else {
				quantity = patch.gameObject.GetComponent<FoodData> ().amount;
			}
			if (quantity > 0) {
				sugar = sugar + quantity - metabolism;
				patch.gameObject.GetComponent<FoodData> ().amount -= 10;
				//Aumentar el fitness
				fitness += 1;

			} else {
				sugar -= 0.5f;
			}
			if (sugar <= 0) {
				Destroy (this.gameObject);
			}
		}
	}
}
