﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RDCell{
	public float A = 1.0f;
	public float B = 0f;
}
