﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodData : MonoBehaviour {
	public int maxAmount = 10;
	public int amount = 0;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
