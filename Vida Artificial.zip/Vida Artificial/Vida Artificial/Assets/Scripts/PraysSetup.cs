﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PraysSetup : MonoBehaviour {
	public GameObject Pray;


	// Use this for initialization
	void Start () {
		GameObject newPray = (GameObject)Instantiate (Pray);
		newPray.transform.position = new Vector3(0, 0, 0);
		newPray.transform.parent = transform;
		for (int x = 0; x < 10; x++) {
			newPray = (GameObject)Instantiate (Pray);
			newPray.transform.position = new Vector3 (4*x, 0, 0);
			newPray.transform.parent = transform;
		}

	}
}
